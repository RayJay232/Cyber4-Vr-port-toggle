@echo off
setlocal

set "targetDir=D:\SteamLibrary\steamapps\common\Cyberpunk 2077\red4ext\plugins\cyberpunkvrport"

if exist "%targetDir%\cyberpunkvrport.dll.bak" (
    ren "%targetDir%\cyberpunkvrport.dll.bak" cyberpunkvrport.dll
    echo ========================================
    echo         VR Has Been Toggled On         
    echo ========================================
) else if exist "%targetDir%\cyberpunkvrport.dll" (
    ren "%targetDir%\cyberpunkvrport.dll" cyberpunkvrport.dll.bak
    echo ========================================
    echo         VR Has Been Toggled Off        
    echo ========================================
) else (
    echo ========================================
    echo   Neither cyberpunkvrport.dll nor cyberpunkvrport.dll.bak    
    echo           was found.                  
	echo ----------------------------------------
    call echo   Checked path: %%targetDir%%
    echo ========================================
)

endlocal
pause